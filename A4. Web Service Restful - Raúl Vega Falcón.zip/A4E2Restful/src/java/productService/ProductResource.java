/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productService;

import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Stateless
@Path("/product")
public class ProductResource {

    static Product product;
    
    @GET
    @Produces({"application/json", "application/xml"})
    public Product read() {
        return product;
    }

    @POST
    @Consumes("application/json")
    public Response save_JSON(Product p) {
        product = p;
        return Response.ok().build();
    }
}
